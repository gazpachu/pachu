---------------------------------------------------------------------------
           The South Park 3D Spectacular! v1.5 for Win95/98/NT4
               (Formerly The Eric Cartman 3D Extravaganza!)
                            by ROBERT BENNETT
                     EMAIL: Rob@UselessCreations.com
                              ICQ# 14073622
                        RELEASED: 4th April, 2000
                http://www.UselessCreations.com/southpark
---------------------------------------------------------------------------
                        Want more pointless crap?
                     http://www.UselessCreations.com
               Screen savers. Games. Three Legged Weasels.
---------------------------------------------------------------------------

* ARCHIVE CONTENTS

  SouthPark3D.ZIP
    - South Park 3D Spectacular!.scr
    - readme.txt


* INSTALLATION

  To install, simply copy the "South Park 3D Spectacular!.scr" file to 
  the windows folder (normaly C:\WINDOWS). Then go the Display options in
  Control Panel and in the Screen Saver section select:
  South Park 3D Spectacular!
  Then sit back, munch some Cheesy Poofs and enjoy!

  To remove simply delete the "South Park 3D Spectacular!.scr" file from
  the windows folder, but why you want to do this is beyond my 
  comprehension.


* SETTINGS:

  To get to the settings screen go to Display options in Control Panel and
  in the Screen Saver section click on Settings.

  Polygon Resolution sets how many polygons make up the characters. The 
  higher its set the better he looks but the slower it'll run. 

  The Size option lets you set how big they'll be on the screen. Bigger is
  slower cos um.. it's bigger. 

  If you've got the PC power stick both options all the way up.

  The Sound check box lets you turn sound on and off. Obviously.

  The Delay between characters lets you select whether its a short or long
  pause between changes. Note that if ya set it too short you might miss
  stuff. 

* RELEASE NOTES (v1.5):

  Howdy!

  This is basically a bugfix version because its already been 4 months
  since the very buggy version 1.0 was released (well it wasnt that
  buggy but it had some annoying ones).

  Main bug was the one where if you had sound turned off Kenny would
  still scream when he died. This was an accident but I absolutely
  pissed myself when I started getting emails about it!

  I've had nothing but positive responses to this screen saver. I'm glad
  so many people like it. It was featured on the front of www.download.com
  for over a week, and as a result it was downloaded about 100,000 times
  in that first week!

  Anyway if the positive response continues I'll finish off adding some
  more characters for v2.0 of this beast.

  Enjoy!

  PS. I'd like to apologise to all those people who downloaded the 
  butchered version of this. Some ficticious version 1.3??? It included
  some lotto scam and buggered with your homepage settings.
  THIS WAS NOT DONE BY ME!!! I put a stop to it as soon as I could.
  I spoke to download.com and they assure me it'll never be allowed
  to happen again. Lets hope.


* RELEASE NOTES:

  Well about 5 months ago to the day I released The Eric Cartman 3D
  Extravaganza! and I'm happy to say it was quite popular.

  After it was listed on the front of www.download.com it went kinda sick
  and by last count has been downloaded afew hundred thousand times!!

  Well... I was impressed.

  Best of all I had a record amount of emails that simply read:

  "Sweeeeeet!"

  Then I had a shitload of emails saying:

  "Do Kenny!!"

  Then I had afew complaints from people who had trouble running it.
  (Some were quite abusive. It was cool! Altho.. complaining about free
  stuff doesnt quite make sense to me...)
  Turns out some people were running wierd ass video cards that didn't
  like it and bits of Cartman were see through or something. I never
  saw it myself but I had enough complaints to get me worried.

  So I started it again from scratch using VC++5 instead of BCB4, sent a
  copy to the complainants and got positive responses. Which was sweeet.

  So I did Kenny and made him die brutally. 
  Then thought, "I've done this much I may aswell finish it off." 
  So I added Kyle and Stan.

  And here it is just in time for Christmas!

  It uses Microsoft's implementation of OpenGL which comes with all 
  versions of Win95/98/NT except for Windows95a (I think), so pretty much
  everyone should already have it. But if you need it you can get it here:

  ftp://ftp.microsoft.com/softlib/mslfiles/opengl95.exe

  You'll know if you need it cos you'll get some kind of DLL error.
  Something like GLU32.DLL or OPENGL32.DLL is missing.

  Hope you all enjoy it. If ya do email me!

  If ya don't.. well then I'll kick you right in the nuts!!
  But you can still email me if you want.

  If ya spot any creepy crawlies let me know. I got kind of confused when I was debugging
  and I'm kinda paranoid that I forgot to turn something back off/on...

  As with everything else I've done (visit the website for more) if I get
  a good response I'll try and add more. But we'll have to wait and see.
  (I'm sick of the sight of Cartman's fat ass.)

  Merry Xmas n all that. And I hope you all get to see this before the
  Y2K thingy destroys the world. I'll see you all in the queue to loot
  the TV store early in the new year.

  Enjoy!


* VERSION HISTORY

  1.5   04/04/2000  Second release. Fixed alot of bugs. Including
                    Kenny's scream when sounds turned off.
                    Kenny would also just hang in the middle of the
                    screen after he died. Fixed.
                    Added UC logo cos its all about branding, people!

  1.0   23/12/1999  First version of the South Park 3D Spectacular!
                    - Now features Cartman, Kenny, Stan, Kyle and more.
                    - Characters now blink and their mouths move
                      when they talk
                    - Each character has a random event type deal.
                      (YES boys and girls. Kenny does die)
                    - Complete re-write from scratch. Now done in VC++5.
                      Some video cards didn't like the old version and
                      displayed Cartman partially transparent??
                      Never saw it myself but I had alot of complaints.
                      (Actually I got shitloads of abuse about it.)

  1.0    24/7/1999  Original Release - The Eric Cartman 3D Extravaganza!
                                     - Just featured Cartman.

---------------------------------------------------------------------------
SOUTH PARK and all associated characters are Copyright � Comedy Central.
The screen saver itself is Copyright � Robert Bennett 2000.
This software was made as a tribute to SOUTH PARK.
No copyright infringement is intended.
This software is FREE and may not be used for profit.
If you like and use it, send me an email!
---------------------------------------------------------------------------
This screen saver is provided as is. The author takes no responsibility
for any damage that is done to your system thru it's use.
It works fine for me! If it doesn't for you, it aint my fault!
This product is not guaranteed to save your screen from burn in or any
other form of damage. (eg. painting it the colour of a cheesy poof and
feeding it to a fatass)
---------------------------------------------------------------------------
